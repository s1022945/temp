﻿namespace SMCSwitch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblA0ItemName = new System.Windows.Forms.Label();
            this.lblA1ItemName = new System.Windows.Forms.Label();
            this.lblA2ItemName = new System.Windows.Forms.Label();
            this.lblA3ItemName = new System.Windows.Forms.Label();
            this.lblA4ItemName = new System.Windows.Forms.Label();
            this.lblA5ItemName = new System.Windows.Forms.Label();
            this.lblA0Val = new System.Windows.Forms.Label();
            this.lblA1Val = new System.Windows.Forms.Label();
            this.lblA2Val = new System.Windows.Forms.Label();
            this.lblA3Val = new System.Windows.Forms.Label();
            this.lblA4Val = new System.Windows.Forms.Label();
            this.lblA5Val = new System.Windows.Forms.Label();
            this.lblA0USL = new System.Windows.Forms.Label();
            this.lblA1USL = new System.Windows.Forms.Label();
            this.lblA2USL = new System.Windows.Forms.Label();
            this.lblA3USL = new System.Windows.Forms.Label();
            this.lblA4USL = new System.Windows.Forms.Label();
            this.lblA5USL = new System.Windows.Forms.Label();
            this.lblA5LSL = new System.Windows.Forms.Label();
            this.lblA4LSL = new System.Windows.Forms.Label();
            this.lblA3LSL = new System.Windows.Forms.Label();
            this.lblA2LSL = new System.Windows.Forms.Label();
            this.lblA1LSL = new System.Windows.Forms.Label();
            this.lblA0LSL = new System.Windows.Forms.Label();
            this.lblA0Status = new System.Windows.Forms.Label();
            this.lblA1Status = new System.Windows.Forms.Label();
            this.lblA2Status = new System.Windows.Forms.Label();
            this.lblA3Status = new System.Windows.Forms.Label();
            this.lblA4Status = new System.Windows.Forms.Label();
            this.lblA5Status = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.cbxComport = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblUpdateTime = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblEQID = new System.Windows.Forms.Label();
            this.lblLineID = new System.Windows.Forms.Label();
            this.Tsecond = new System.Windows.Forms.Timer(this.components);
            this.TUpdate = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.TEDC = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblA0ItemName, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblA1ItemName, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblA2ItemName, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblA3ItemName, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblA4ItemName, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblA5ItemName, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblA0Val, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblA1Val, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblA2Val, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblA3Val, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblA4Val, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblA5Val, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblA0USL, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblA1USL, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblA2USL, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblA3USL, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblA4USL, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblA5USL, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblA5LSL, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblA4LSL, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblA3LSL, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblA2LSL, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblA1LSL, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblA0LSL, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblA0Status, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblA1Status, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblA2Status, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblA3Status, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblA4Status, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblA5Status, 2, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(542, 198);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "No.";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(120, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(253, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Status";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(328, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Value";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(408, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "USL";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(484, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "LSL";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "A0";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "A1";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 19);
            this.label9.TabIndex = 0;
            this.label9.Text = "A2";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 116);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 19);
            this.label10.TabIndex = 0;
            this.label10.Text = "A3";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 143);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 19);
            this.label11.TabIndex = 0;
            this.label11.Text = "A4";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 172);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 19);
            this.label12.TabIndex = 0;
            this.label12.Text = "A5";
            // 
            // lblA0ItemName
            // 
            this.lblA0ItemName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA0ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA0ItemName.Location = new System.Drawing.Point(73, 34);
            this.lblA0ItemName.Name = "lblA0ItemName";
            this.lblA0ItemName.Size = new System.Drawing.Size(145, 21);
            this.lblA0ItemName.TabIndex = 0;
            this.lblA0ItemName.Text = "ItemName";
            this.lblA0ItemName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA1ItemName
            // 
            this.lblA1ItemName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA1ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1ItemName.Location = new System.Drawing.Point(73, 61);
            this.lblA1ItemName.Name = "lblA1ItemName";
            this.lblA1ItemName.Size = new System.Drawing.Size(145, 21);
            this.lblA1ItemName.TabIndex = 0;
            this.lblA1ItemName.Text = "ItemName";
            this.lblA1ItemName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA2ItemName
            // 
            this.lblA2ItemName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA2ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2ItemName.Location = new System.Drawing.Point(73, 88);
            this.lblA2ItemName.Name = "lblA2ItemName";
            this.lblA2ItemName.Size = new System.Drawing.Size(145, 21);
            this.lblA2ItemName.TabIndex = 0;
            this.lblA2ItemName.Text = "ItemName";
            this.lblA2ItemName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA3ItemName
            // 
            this.lblA3ItemName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA3ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3ItemName.Location = new System.Drawing.Point(73, 115);
            this.lblA3ItemName.Name = "lblA3ItemName";
            this.lblA3ItemName.Size = new System.Drawing.Size(145, 21);
            this.lblA3ItemName.TabIndex = 0;
            this.lblA3ItemName.Text = "ItemName";
            this.lblA3ItemName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA4ItemName
            // 
            this.lblA4ItemName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA4ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4ItemName.Location = new System.Drawing.Point(73, 142);
            this.lblA4ItemName.Name = "lblA4ItemName";
            this.lblA4ItemName.Size = new System.Drawing.Size(145, 21);
            this.lblA4ItemName.TabIndex = 0;
            this.lblA4ItemName.Text = "ItemName";
            this.lblA4ItemName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA5ItemName
            // 
            this.lblA5ItemName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA5ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA5ItemName.Location = new System.Drawing.Point(73, 171);
            this.lblA5ItemName.Name = "lblA5ItemName";
            this.lblA5ItemName.Size = new System.Drawing.Size(145, 21);
            this.lblA5ItemName.TabIndex = 0;
            this.lblA5ItemName.Text = "ItemName";
            this.lblA5ItemName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA0Val
            // 
            this.lblA0Val.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA0Val.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA0Val.Location = new System.Drawing.Point(320, 34);
            this.lblA0Val.Name = "lblA0Val";
            this.lblA0Val.Size = new System.Drawing.Size(69, 21);
            this.lblA0Val.TabIndex = 0;
            this.lblA0Val.Text = "Val";
            this.lblA0Val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA1Val
            // 
            this.lblA1Val.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA1Val.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1Val.Location = new System.Drawing.Point(320, 61);
            this.lblA1Val.Name = "lblA1Val";
            this.lblA1Val.Size = new System.Drawing.Size(69, 21);
            this.lblA1Val.TabIndex = 0;
            this.lblA1Val.Text = "Val";
            this.lblA1Val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA2Val
            // 
            this.lblA2Val.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA2Val.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2Val.Location = new System.Drawing.Point(320, 88);
            this.lblA2Val.Name = "lblA2Val";
            this.lblA2Val.Size = new System.Drawing.Size(69, 21);
            this.lblA2Val.TabIndex = 0;
            this.lblA2Val.Text = "Val";
            this.lblA2Val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA3Val
            // 
            this.lblA3Val.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA3Val.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3Val.Location = new System.Drawing.Point(320, 115);
            this.lblA3Val.Name = "lblA3Val";
            this.lblA3Val.Size = new System.Drawing.Size(69, 21);
            this.lblA3Val.TabIndex = 0;
            this.lblA3Val.Text = "Val";
            this.lblA3Val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA4Val
            // 
            this.lblA4Val.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA4Val.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4Val.Location = new System.Drawing.Point(320, 142);
            this.lblA4Val.Name = "lblA4Val";
            this.lblA4Val.Size = new System.Drawing.Size(69, 21);
            this.lblA4Val.TabIndex = 0;
            this.lblA4Val.Text = "Val";
            this.lblA4Val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA5Val
            // 
            this.lblA5Val.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA5Val.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA5Val.Location = new System.Drawing.Point(320, 171);
            this.lblA5Val.Name = "lblA5Val";
            this.lblA5Val.Size = new System.Drawing.Size(69, 21);
            this.lblA5Val.TabIndex = 0;
            this.lblA5Val.Text = "Val";
            this.lblA5Val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA0USL
            // 
            this.lblA0USL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA0USL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA0USL.Location = new System.Drawing.Point(404, 34);
            this.lblA0USL.Name = "lblA0USL";
            this.lblA0USL.Size = new System.Drawing.Size(50, 21);
            this.lblA0USL.TabIndex = 0;
            this.lblA0USL.Text = "USL";
            this.lblA0USL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA1USL
            // 
            this.lblA1USL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA1USL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1USL.Location = new System.Drawing.Point(404, 61);
            this.lblA1USL.Name = "lblA1USL";
            this.lblA1USL.Size = new System.Drawing.Size(50, 21);
            this.lblA1USL.TabIndex = 0;
            this.lblA1USL.Text = "USL";
            this.lblA1USL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA2USL
            // 
            this.lblA2USL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA2USL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2USL.Location = new System.Drawing.Point(404, 88);
            this.lblA2USL.Name = "lblA2USL";
            this.lblA2USL.Size = new System.Drawing.Size(50, 21);
            this.lblA2USL.TabIndex = 0;
            this.lblA2USL.Text = "USL";
            this.lblA2USL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA3USL
            // 
            this.lblA3USL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA3USL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3USL.Location = new System.Drawing.Point(404, 115);
            this.lblA3USL.Name = "lblA3USL";
            this.lblA3USL.Size = new System.Drawing.Size(50, 21);
            this.lblA3USL.TabIndex = 0;
            this.lblA3USL.Text = "USL";
            this.lblA3USL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA4USL
            // 
            this.lblA4USL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA4USL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4USL.Location = new System.Drawing.Point(404, 142);
            this.lblA4USL.Name = "lblA4USL";
            this.lblA4USL.Size = new System.Drawing.Size(50, 21);
            this.lblA4USL.TabIndex = 0;
            this.lblA4USL.Text = "USL";
            this.lblA4USL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA5USL
            // 
            this.lblA5USL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA5USL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA5USL.Location = new System.Drawing.Point(404, 171);
            this.lblA5USL.Name = "lblA5USL";
            this.lblA5USL.Size = new System.Drawing.Size(50, 21);
            this.lblA5USL.TabIndex = 0;
            this.lblA5USL.Text = "USL";
            this.lblA5USL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA5LSL
            // 
            this.lblA5LSL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA5LSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA5LSL.Location = new System.Drawing.Point(479, 171);
            this.lblA5LSL.Name = "lblA5LSL";
            this.lblA5LSL.Size = new System.Drawing.Size(50, 21);
            this.lblA5LSL.TabIndex = 0;
            this.lblA5LSL.Text = "LSL";
            this.lblA5LSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA4LSL
            // 
            this.lblA4LSL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA4LSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4LSL.Location = new System.Drawing.Point(479, 142);
            this.lblA4LSL.Name = "lblA4LSL";
            this.lblA4LSL.Size = new System.Drawing.Size(50, 21);
            this.lblA4LSL.TabIndex = 0;
            this.lblA4LSL.Text = "LSL";
            this.lblA4LSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA3LSL
            // 
            this.lblA3LSL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA3LSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3LSL.Location = new System.Drawing.Point(479, 115);
            this.lblA3LSL.Name = "lblA3LSL";
            this.lblA3LSL.Size = new System.Drawing.Size(50, 21);
            this.lblA3LSL.TabIndex = 0;
            this.lblA3LSL.Text = "LSL";
            this.lblA3LSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA2LSL
            // 
            this.lblA2LSL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA2LSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2LSL.Location = new System.Drawing.Point(479, 88);
            this.lblA2LSL.Name = "lblA2LSL";
            this.lblA2LSL.Size = new System.Drawing.Size(50, 21);
            this.lblA2LSL.TabIndex = 0;
            this.lblA2LSL.Text = "LSL";
            this.lblA2LSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA1LSL
            // 
            this.lblA1LSL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA1LSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1LSL.Location = new System.Drawing.Point(479, 61);
            this.lblA1LSL.Name = "lblA1LSL";
            this.lblA1LSL.Size = new System.Drawing.Size(50, 21);
            this.lblA1LSL.TabIndex = 0;
            this.lblA1LSL.Text = "LSL";
            this.lblA1LSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA0LSL
            // 
            this.lblA0LSL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA0LSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA0LSL.Location = new System.Drawing.Point(479, 34);
            this.lblA0LSL.Name = "lblA0LSL";
            this.lblA0LSL.Size = new System.Drawing.Size(50, 21);
            this.lblA0LSL.TabIndex = 0;
            this.lblA0LSL.Text = "LSL";
            this.lblA0LSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblA0Status
            // 
            this.lblA0Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA0Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA0Status.Location = new System.Drawing.Point(270, 35);
            this.lblA0Status.Name = "lblA0Status";
            this.lblA0Status.Size = new System.Drawing.Size(19, 19);
            this.lblA0Status.TabIndex = 0;
            // 
            // lblA1Status
            // 
            this.lblA1Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA1Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA1Status.Location = new System.Drawing.Point(270, 62);
            this.lblA1Status.Name = "lblA1Status";
            this.lblA1Status.Size = new System.Drawing.Size(19, 19);
            this.lblA1Status.TabIndex = 0;
            // 
            // lblA2Status
            // 
            this.lblA2Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA2Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA2Status.Location = new System.Drawing.Point(270, 89);
            this.lblA2Status.Name = "lblA2Status";
            this.lblA2Status.Size = new System.Drawing.Size(19, 19);
            this.lblA2Status.TabIndex = 0;
            // 
            // lblA3Status
            // 
            this.lblA3Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA3Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA3Status.Location = new System.Drawing.Point(270, 116);
            this.lblA3Status.Name = "lblA3Status";
            this.lblA3Status.Size = new System.Drawing.Size(19, 19);
            this.lblA3Status.TabIndex = 0;
            // 
            // lblA4Status
            // 
            this.lblA4Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA4Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA4Status.Location = new System.Drawing.Point(270, 143);
            this.lblA4Status.Name = "lblA4Status";
            this.lblA4Status.Size = new System.Drawing.Size(19, 19);
            this.lblA4Status.TabIndex = 0;
            // 
            // lblA5Status
            // 
            this.lblA5Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblA5Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblA5Status.Location = new System.Drawing.Point(270, 172);
            this.lblA5Status.Name = "lblA5Status";
            this.lblA5Status.Size = new System.Drawing.Size(19, 19);
            this.lblA5Status.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblStatus);
            this.groupBox1.Controls.Add(this.cbxComport);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.btnStop);
            this.groupBox1.Controls.Add(this.btnStart);
            this.groupBox1.Controls.Add(this.lblUpdateTime);
            this.groupBox1.Controls.Add(this.lblTime);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.lblEQID);
            this.groupBox1.Controls.Add(this.lblLineID);
            this.groupBox1.Location = new System.Drawing.Point(12, 216);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(542, 92);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.lblStatus.Location = new System.Drawing.Point(160, 63);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(98, 12);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "Status: disconnected";
            // 
            // cbxComport
            // 
            this.cbxComport.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.cbxComport.FormattingEnabled = true;
            this.cbxComport.Location = new System.Drawing.Point(59, 60);
            this.cbxComport.Name = "cbxComport";
            this.cbxComport.Size = new System.Drawing.Size(66, 20);
            this.cbxComport.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.label15.Location = new System.Drawing.Point(6, 63);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "Comport";
            // 
            // btnStop
            // 
            this.btnStop.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.btnStop.Location = new System.Drawing.Point(461, 63);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.btnStart.Location = new System.Drawing.Point(376, 63);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblUpdateTime
            // 
            this.lblUpdateTime.AutoSize = true;
            this.lblUpdateTime.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.lblUpdateTime.Location = new System.Drawing.Point(501, 26);
            this.lblUpdateTime.Name = "lblUpdateTime";
            this.lblUpdateTime.Size = new System.Drawing.Size(35, 12);
            this.lblUpdateTime.TabIndex = 0;
            this.lblUpdateTime.Text = "00000";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.lblTime.Location = new System.Drawing.Point(369, 26);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(35, 12);
            this.lblTime.TabIndex = 0;
            this.lblTime.Text = "00000";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.label19.Location = new System.Drawing.Point(425, 26);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "Update time:  ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.label18.Location = new System.Drawing.Point(268, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "EDC upload time:  ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.label17.Location = new System.Drawing.Point(296, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "EQID:";
            // 
            // lblEQID
            // 
            this.lblEQID.AutoSize = true;
            this.lblEQID.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.lblEQID.Location = new System.Drawing.Point(160, 26);
            this.lblEQID.Name = "lblEQID";
            this.lblEQID.Size = new System.Drawing.Size(35, 12);
            this.lblEQID.TabIndex = 0;
            this.lblEQID.Text = "EQID:";
            // 
            // lblLineID
            // 
            this.lblLineID.AutoSize = true;
            this.lblLineID.Font = new System.Drawing.Font("PMingLiU", 9F);
            this.lblLineID.Location = new System.Drawing.Point(6, 26);
            this.lblLineID.Name = "lblLineID";
            this.lblLineID.Size = new System.Drawing.Size(41, 12);
            this.lblLineID.TabIndex = 0;
            this.lblLineID.Text = "LineID:";
            // 
            // Tsecond
            // 
            this.Tsecond.Interval = 1000;
            this.Tsecond.Tick += new System.EventHandler(this.Tsecond_Tick);
            // 
            // TUpdate
            // 
            this.TUpdate.Tick += new System.EventHandler(this.TUpdate_Tick);
            // 
            // TEDC
            // 
            this.TEDC.Tick += new System.EventHandler(this.TEDC_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 320);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("PMingLiU", 14F);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblA0ItemName;
        private System.Windows.Forms.Label lblA1ItemName;
        private System.Windows.Forms.Label lblA2ItemName;
        private System.Windows.Forms.Label lblA3ItemName;
        private System.Windows.Forms.Label lblA4ItemName;
        private System.Windows.Forms.Label lblA5ItemName;
        private System.Windows.Forms.Label lblA0Val;
        private System.Windows.Forms.Label lblA1Val;
        private System.Windows.Forms.Label lblA2Val;
        private System.Windows.Forms.Label lblA3Val;
        private System.Windows.Forms.Label lblA4Val;
        private System.Windows.Forms.Label lblA5Val;
        private System.Windows.Forms.Label lblA0USL;
        private System.Windows.Forms.Label lblA1USL;
        private System.Windows.Forms.Label lblA2USL;
        private System.Windows.Forms.Label lblA3USL;
        private System.Windows.Forms.Label lblA4USL;
        private System.Windows.Forms.Label lblA5USL;
        private System.Windows.Forms.Label lblA5LSL;
        private System.Windows.Forms.Label lblA4LSL;
        private System.Windows.Forms.Label lblA3LSL;
        private System.Windows.Forms.Label lblA2LSL;
        private System.Windows.Forms.Label lblA1LSL;
        private System.Windows.Forms.Label lblA0LSL;
        private System.Windows.Forms.Label lblA0Status;
        private System.Windows.Forms.Label lblA1Status;
        private System.Windows.Forms.Label lblA2Status;
        private System.Windows.Forms.Label lblA3Status;
        private System.Windows.Forms.Label lblA4Status;
        private System.Windows.Forms.Label lblA5Status;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ComboBox cbxComport;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblUpdateTime;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblEQID;
        private System.Windows.Forms.Label lblLineID;
        private System.Windows.Forms.Timer Tsecond;
        private System.Windows.Forms.Timer TUpdate;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer TEDC;



    }
}

