﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using System.Xml;


namespace SMCSwitch_mutiSensor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            string[] myPorts = SerialPort.GetPortNames(); //取得所有port的名字的方法
            cbxComport.DataSource = myPorts;   //直接取得所有port的名字
        }

        List<string> toRead = new List<string>();
        List<float> a = new List<float>();
        List<float> b = new List<float>();
        string FSPath, LineID, EQID;
        string[] sensorList;
        int SearchingRow;

        private void Form1_Load(object sender, EventArgs e)
        {
            
            //Ini Setting
            //string tempStr;
            sensorList = OperateIniFile.ReadIniData("EQSetting", "SensorList", "", Path.GetFullPath("config.ini")).ToString().Split(',');
            LineID = OperateIniFile.ReadIniData("EQSetting", "LineID", "", Path.GetFullPath("config.ini"));
            lblLineID.Text = "LineID: " + LineID;
            EQID = OperateIniFile.ReadIniData("EQSetting", "EQID", "", Path.GetFullPath("config.ini"));
            lblEQID.Text = "EQID: " + EQID;
            lblTime.Text = OperateIniFile.ReadIniData("EQSetting", "EDCTime", "600", Path.GetFullPath("config.ini"));
            TEDC.Interval = int.Parse(lblTime.Text) * 1000;
            lblUpdateTime.Text = OperateIniFile.ReadIniData("EQSetting", "UpdateTime", "5", Path.GetFullPath("config.ini"));
            TUpdate.Interval =  int.Parse(lblUpdateTime.Text) * 1000;
            this.Text = "SMCSwitch - " + EQID;

            FSPath = OperateIniFile.ReadIniData("EQSetting", "FSPath", "", Path.GetFullPath("config.ini"));
            SearchingRow = int.Parse(OperateIniFile.ReadIniData("EQSetting", "SearchingRow", "10", Path.GetFullPath("config.ini")));
            
            int row_pitch = 27;
            //string[] header = ["No.", "Name", "Status", "Value", ""]
            foreach (string sensor in sensorList)
            {
                tabMain.TabPages.Add(sensor);
                //MessageBox.Show(tabMain.TabPages[j].Text);


                string tempStr;
                for (int i = -1; i <= 5; i++)
                {
                    Label newLabel = new Label();
                    if (i == -1)    //Header
                    {
                        //No.
                        newLabel = new Label();
                        newLabel.Text = "No.";
                        newLabel.Size = new Size(35, 19);
                        newLabel.Font = new Font("新細明體", 14);
                        newLabel.TextAlign = ContentAlignment.MiddleCenter;
                        newLabel.Location = new Point(9, 34 + i * row_pitch);
                        //newLabel.Name = "lbl" + sensor + "A" + i.ToString(); //lblsensorA0
                        tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                        //Name
                        newLabel = new Label();
                        newLabel.Text = "Name";
                        newLabel.Size = new Size(145, 21);
                        newLabel.Font = new Font("新細明體", 14);
                        newLabel.TextAlign = ContentAlignment.MiddleCenter;
                        newLabel.Location = new Point(73, 34 + i * row_pitch);
                        tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                        //Status
                        newLabel = new Label();
                        newLabel.Text = "Status";
                        newLabel.Size = new Size(53, 21);
                        newLabel.Font = new Font("新細明體", 14);
                        newLabel.TextAlign = ContentAlignment.MiddleCenter;
                        newLabel.Location = new Point(253, 34 + i * row_pitch);
                        tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                        //Value
                        newLabel = new Label();
                        newLabel.Text = "Value";
                        newLabel.Size = new Size(52, 21);
                        newLabel.Font = new Font("新細明體", 14);
                        newLabel.TextAlign = ContentAlignment.MiddleCenter;
                        newLabel.Location = new Point(328, 34 + i * row_pitch);
                        tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                        //USL
                        newLabel = new Label();
                        newLabel.Text = "USL";
                        newLabel.Size = new Size(43, 21);
                        newLabel.Font = new Font("新細明體", 14);
                        newLabel.TextAlign = ContentAlignment.MiddleCenter;
                        newLabel.Location = new Point(408, 34 + i * row_pitch);
                        tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                        //LSL
                        newLabel = new Label();
                        newLabel.Text = "LSL";
                        newLabel.Size = new Size(43, 21);
                        newLabel.Font = new Font("新細明體", 14);
                        newLabel.TextAlign = ContentAlignment.MiddleCenter;
                        newLabel.Location = new Point(484, 34 + i * row_pitch);
                        tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                        tempStr = "";
                    }

                    else    //raw data
                    {
                        //A0 - A5 Label
                        newLabel = new Label();
                        newLabel.Text = "A" + i.ToString();
                        newLabel.Size = new Size(35, 19);
                        newLabel.Font = new Font("新細明體", 14);
                        newLabel.TextAlign = ContentAlignment.MiddleCenter;
                        newLabel.Location = new Point(9, 34 + i * row_pitch);
                        tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);
                        
                        tempStr = OperateIniFile.ReadIniData(sensor + "A" + i.ToString(), "Name", "", Path.GetFullPath("config.ini"));

                        if (tempStr != "")
                        {
                            toRead.Add(sensor + "A" + i.ToString());
                            a.Add(float.Parse(OperateIniFile.ReadIniData(sensor + "A" + i.ToString(), "a", "1", Path.GetFullPath("config.ini"))));
                            b.Add(float.Parse(OperateIniFile.ReadIniData(sensor + "A" + i.ToString(), "b", "0", Path.GetFullPath("config.ini"))));

                            //Item Name
                            newLabel = new Label();
                            newLabel.Text = tempStr;
                            newLabel.Size = new Size(145, 21);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(73, 34 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "ItemName"; //lblsensorA0ItemName
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                            //Status
                            newLabel = new Label();
                            newLabel.Text = "";
                            newLabel.Size = new Size(19, 19);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(270, 35 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.BackColor = Control.DefaultBackColor;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "Status"; //lblsensorA0Status
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                            //Value
                            newLabel = new Label();
                            newLabel.Text = "";
                            newLabel.Size = new Size(69, 21);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(320, 34 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "Val"; //lblsensorA0Val
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                            //USL
                            tempStr = OperateIniFile.ReadIniData(sensor + "A" + i.ToString(), "USL", "", Path.GetFullPath("config.ini"));
                            if (tempStr != "")
                            {
                                newLabel = new Label();
                                newLabel.Text = tempStr;
                                newLabel.Size = new Size(50, 21);
                                newLabel.Font = new Font("新細明體", 14);
                                newLabel.TextAlign = ContentAlignment.MiddleCenter;
                                newLabel.Location = new Point(404, 34 + i * row_pitch);
                                newLabel.BorderStyle = BorderStyle.FixedSingle;
                                newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "USL"; //lblsensorA0USL
                                tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);
                            }
                            else
                            {
                                newLabel = new Label();
                                newLabel.Text = "-";
                                newLabel.Size = new Size(50, 21);
                                newLabel.Font = new Font("新細明體", 14);
                                newLabel.TextAlign = ContentAlignment.MiddleCenter;
                                newLabel.Location = new Point(404, 34 + i * row_pitch);
                                newLabel.BorderStyle = BorderStyle.FixedSingle;
                                newLabel.BackColor = Color.Gray;
                                newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "USL"; //lblsensorA0USL
                                tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);
                            }

                            //LSL
                            tempStr = OperateIniFile.ReadIniData(sensor + "A" + i.ToString(), "LSL", "", Path.GetFullPath("config.ini"));
                            if (tempStr != "")
                            {
                                newLabel = new Label();
                                newLabel.Text = tempStr;
                                newLabel.Size = new Size(50, 21);
                                newLabel.Font = new Font("新細明體", 14);
                                newLabel.TextAlign = ContentAlignment.MiddleCenter;
                                newLabel.Location = new Point(479, 34 + i * row_pitch);
                                newLabel.BorderStyle = BorderStyle.FixedSingle;
                                //newLabel.BackColor = Color.Gray;
                                newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "LSL"; //lblsensorA0LSL
                                tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);
                            }
                            else
                            {
                                newLabel = new Label();
                                newLabel.Text = "-";
                                newLabel.Size = new Size(50, 21);
                                newLabel.Font = new Font("新細明體", 14);
                                newLabel.TextAlign = ContentAlignment.MiddleCenter;
                                newLabel.Location = new Point(479, 34 + i * row_pitch);
                                newLabel.BorderStyle = BorderStyle.FixedSingle;
                                newLabel.BackColor = Color.Gray;
                                newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "LSL"; //lblsensorA0LSL
                                tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);
                            }

                            

                        }
                        else
                        {
                            //Item Name
                            newLabel = new Label();
                            newLabel.Text = "-";
                            newLabel.Size = new Size(145, 21);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(73, 34 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.BackColor = Color.Gray;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "ItemName"; //lblsensorA0ItemName
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                            //Status
                            newLabel = new Label();
                            newLabel.Text = "";
                            newLabel.Size = new Size(19, 19);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(270, 35 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.BackColor = Color.Gray;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "Status"; //lblsensorA0Status
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                            //Value
                            newLabel = new Label();
                            newLabel.Text = "-";
                            newLabel.Size = new Size(69, 21);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(320, 34 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.BackColor = Color.Gray;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "Val"; //lblsensorA0Val
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                            //USL
                            newLabel = new Label();
                            newLabel.Text = "-";
                            newLabel.Size = new Size(50, 21);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(404, 34 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.BackColor = Color.Gray;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "USL"; //lblsensorA0Val
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);

                            //LSL
                            newLabel = new Label();
                            newLabel.Text = "-";
                            newLabel.Size = new Size(50, 21);
                            newLabel.Font = new Font("新細明體", 14);
                            newLabel.TextAlign = ContentAlignment.MiddleCenter;
                            newLabel.Location = new Point(479, 34 + i * row_pitch);
                            newLabel.BorderStyle = BorderStyle.FixedSingle;
                            newLabel.BackColor = Color.Gray;
                            newLabel.Name = "lbl" + sensor + "A" + i.ToString() + "LSL"; //lblsensorA0Val
                            tabMain.TabPages[Array.IndexOf(sensorList, sensor)].Controls.Add(newLabel);
                        }
                    }
                }
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbxComport.Text != "")
                {
                    serialPort1.Close();
                    serialPort1.PortName = cbxComport.Text;
                    serialPort1.Open();
                    if (serialPort1.IsOpen == true)
                    {
                        lblStatus.Text = "Status: connected";

                        string data = serialPort1.ReadExisting();
                        lblTime.Text = lblUpdateTime.Text;
                        TUpdate.Enabled = true;
                        Tsecond.Enabled = true;
                        TEDC.Enabled = true;
                        btnStart.Enabled = false;
                        btnStop.Enabled = true;
                        cbxComport.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.ToString(), "error");
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            lblStatus.Text = "Status: disconnected";
            TUpdate.Enabled = false;
            Tsecond.Enabled = false;
            TEDC.Enabled = false;
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            cbxComport.Enabled = true;
        }

        private void Tsecond_Tick(object sender, EventArgs e)
        {
            if (TEDC.Enabled == true)
                lblTime.Text = (int.Parse(lblTime.Text) - 1).ToString();
            if(TUpdate.Enabled == true)
                lblUpdateTime.Text = (int.Parse(lblUpdateTime.Text) - 1).ToString();
        }

        private void TUpdate_Tick(object sender, EventArgs e)
        {
            TUpdate.Enabled = false;
            lblUpdateTime.Text = (TUpdate.Interval / 1000).ToString();
            string data = serialPort1.ReadExisting();
            string[] data_split = data.Split("\n".ToCharArray());
            string[,] Ary_Val = new string[sensorList.Length, 1];

            int r = 0;
            while (r < SearchingRow && r < data_split.Length)
            {
                try{
                    string[] tempSnrData = data_split[data_split.Length - 1 - r].ToString().Replace("\r", "").Split(",".ToCharArray());

                    if (tempSnrData.Length == 8 && tempSnrData[0] == tempSnrData[7])
                    {
                        int tempNum = Array.IndexOf(sensorList, tempSnrData[0]);

                        if (Ary_Val[tempNum, 0] == null || Ary_Val[tempNum, 0] == "")
                        {
                            Ary_Val[tempNum, 0] = data_split[data_split.Length - r - 1];
                        } 
                    }
                    r = r + 1;
                }
                
                catch (Exception ex) {
                        MessageBox.Show("GetSensorValError: " + ex.ToString(), "error");
                        r = r + 1;
                    }
            }
            

            for (int i = 0; i < toRead.Count; i++)
            {
                string temp_sname = toRead[i].Substring(0, toRead[i].Length - 2);
                string temp_chname = toRead[i].Substring(toRead[i].Length - 2, 2);
                int tabPagesIdx = Array.IndexOf(sensorList, temp_sname);


                if (Ary_Val[tabPagesIdx, 0] != null && Ary_Val[tabPagesIdx, 0] != "")
                {
                    int sIdx = 1 + int.Parse(temp_chname.Substring(1, 1));
                    string[] snrValAry = Ary_Val[tabPagesIdx, 0].ToString().Replace("\r", "").Split(",".ToCharArray());
                    float toRead_Val = float.Parse(snrValAry[sIdx]);
                    tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "Val", true)[0].Text =
                        (toRead_Val * a[i] + b[i]).ToString("#0.0");

                    if (tabMain.TabPages[tabPagesIdx].Controls.Find("lbl" + temp_sname + temp_chname + "USL", true)[0].Text != "-" ||
                    tabMain.TabPages[tabPagesIdx].Controls.Find("lbl" + temp_sname + temp_chname + "LSL", true)[0].Text != "-")
                    {
                        tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "Status", true)[0].BackColor = Color.Green;

                        if (tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "USL", true)[0].Text != "-") //USL
                        {
                            if (float.Parse(tabMain.TabPages[tabPagesIdx].Controls
                                .Find("lbl" + temp_sname + temp_chname + "Val", true)[0].Text) >
                            float.Parse(tabMain.TabPages[tabPagesIdx].Controls
                                .Find("lbl" + temp_sname + temp_chname + "USL", true)[0].Text))
                            {
                                tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "Status", true)[0].BackColor = Color.Red;
                            }
                        }
                        if (tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "LSL", true)[0].Text != "-") //LSL
                        {
                            if (float.Parse(tabMain.TabPages[tabPagesIdx].Controls
                                .Find("lbl" + temp_sname + temp_chname + "Val", true)[0].Text) <
                                float.Parse(tabMain.TabPages[tabPagesIdx].Controls
                                .Find("lbl" + temp_sname + temp_chname + "LSL", true)[0].Text))
                            {
                                tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "Status", true)[0].BackColor = Color.Red;
                            }
                        }
                    }

                    else
                    {
                        tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "Status", true)[0].BackColor = Color.Green;
                    }

                }
                else
                {
                    tabMain.TabPages[tabPagesIdx].Controls
                        .Find("lbl" + temp_sname + temp_chname + "Val", true)[0].Text = "-";
                }
                TUpdate.Enabled = true;
            }
        }

        private void TEDC_Tick(object sender, EventArgs e)
        {
            TEDC.Enabled = false;
            lblTime.Text = (TEDC.Interval / 1000).ToString();

            string[] Ary_LineID = LineID.Split(",".ToCharArray());
            string[] Ary_EQID = EQID.Split(",".ToCharArray());
            for (int i = 0; i < Ary_LineID.Length; i++)
            {
                updateEDC(Ary_LineID[i], Ary_EQID[i]);
            }

            TEDC.Enabled = true;
        }
        public void updateEDC(string Line, string EQ)
        {
            //writexml
            if (!Directory.Exists(FSPath + Line))
            {
                Directory.CreateDirectory(FSPath + Line);
            }

            XmlTextWriter textWriter = new XmlTextWriter(FSPath + Line + "\\" + EQ + ".xml", Encoding.UTF8);

            // Opens the document  
            textWriter.WriteStartDocument();
            // Write element  
            textWriter.WriteStartElement("utility");

            textWriter.WriteElementString("datetime", DateTime.Now.ToString("yyyyMMddHHmmss"));
            textWriter.WriteElementString("item_cnt", toRead.Count.ToString());

            for (int i = 0; i < toRead.Count; i++)
            {
                textWriter.WriteStartElement("item");

                textWriter.WriteElementString("name", this.Controls.Find("lbl" + toRead[i] + "ItemName", true)[0].Text);
                textWriter.WriteElementString("type", "X");
                if (this.Controls.Find("lbl" + toRead[i] + "Val", true)[0].Text == "-")
                    textWriter.WriteElementString("value", "");
                else
                    textWriter.WriteElementString("value", this.Controls.Find("lbl" + toRead[i] + "Val", true)[0].Text);

                textWriter.WriteEndElement();
            }
            // Close the document  
            textWriter.WriteEndDocument();
            // close writer  
            textWriter.Close();
        }
    }
}