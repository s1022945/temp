﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using System.Xml;


namespace SMCSwitch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            string[] myPorts = SerialPort.GetPortNames(); //取得所有port的名字的方法
            cbxComport.DataSource = myPorts;   //直接取得所有port的名字
        }


        List<string> toRead = new List<string>();
        List<float> a = new List<float>();
        List<float> b = new List<float>();
        string FSPath, LineID, EQID;

        private void Form1_Load(object sender, EventArgs e)
        {
            //Ini Setting
            LineID = OperateIniFile.ReadIniData("EQSetting", "LineID", "", Path.GetFullPath("config.ini"));
            lblLineID.Text = "LineID: " + LineID;
            EQID = OperateIniFile.ReadIniData("EQSetting", "EQID", "", Path.GetFullPath("config.ini"));
            lblEQID.Text = "EQID: " + EQID;
            lblUpdateTime.Text = OperateIniFile.ReadIniData("EQSetting", "EDCTime", "600", Path.GetFullPath("config.ini"));
            TEDC.Interval = int.Parse(lblUpdateTime.Text) * 1000;
            TUpdate.Interval = int.Parse(OperateIniFile.ReadIniData("EQSetting", "UpdateTime", "5", Path.GetFullPath("config.ini"))) * 1000;
            this.Text = "SMCSwitch - " + EQID;
            
            FSPath = OperateIniFile.ReadIniData("EQSetting", "FSPath", "", Path.GetFullPath("config.ini"));

            for (int i = 0; i < 6; i++)
            {
                string tempStr;
                tempStr = OperateIniFile.ReadIniData("A" + i.ToString(), "Name", "", Path.GetFullPath("config.ini"));
                if (tempStr != "")
                {
                    toRead.Add("A" + i.ToString());
                    a.Add(float.Parse(OperateIniFile.ReadIniData("A" + i.ToString(), "a", "1", Path.GetFullPath("config.ini"))));
                    b.Add(float.Parse(OperateIniFile.ReadIniData("A" + i.ToString(), "b", "0", Path.GetFullPath("config.ini"))));
                    
                    //Item Name
                    this.Controls.Find("lblA" + i.ToString() + "ItemName", true)[0].Text = tempStr;
                    //Value
                    this.Controls.Find("lblA" + i.ToString() + "Val", true)[0].Text = "";

                    //LSL
                    tempStr = OperateIniFile.ReadIniData("A" + i.ToString(), "LSL", "", Path.GetFullPath("config.ini"));
                    if (tempStr != "")
                        this.Controls.Find("lblA" + i.ToString() + "LSL", true)[0].Text = tempStr;
                    else
                    {
                        this.Controls.Find("lblA" + i.ToString() + "LSL", true)[0].Text = "-";
                        this.Controls.Find("lblA" + i.ToString() + "LSL", true)[0].BackColor = Color.Gray;
                    }
                    
                    //USL
                    tempStr = OperateIniFile.ReadIniData("A" + i.ToString(), "USL", "", Path.GetFullPath("config.ini"));
                    if (tempStr != "")
                        this.Controls.Find("lblA" + i.ToString() + "USL", true)[0].Text = tempStr;
                    else
                    {
                        this.Controls.Find("lblA" + i.ToString() + "USL", true)[0].Text = "-";
                        this.Controls.Find("lblA" + i.ToString() + "USL", true)[0].BackColor = Color.Gray;
                    }
                    
                }
                else
                {
                    //Item Name
                    this.Controls.Find("lblA" + i.ToString() + "ItemName", true)[0].Text = "-";
                    this.Controls.Find("lblA" + i.ToString() + "ItemName", true)[0].BackColor = Color.Gray;
                    //Status
                    this.Controls.Find("lblA" + i.ToString() + "Status", true)[0].BackColor = Color.Gray;
                    //Value
                    this.Controls.Find("lblA" + i.ToString() + "Val", true)[0].Text = "-";
                    this.Controls.Find("lblA" + i.ToString() + "Val", true)[0].BackColor = Color.Gray;
                    //LSL
                    this.Controls.Find("lblA" + i.ToString() + "LSL", true)[0].Text = "-";
                    this.Controls.Find("lblA" + i.ToString() + "LSL", true)[0].BackColor = Color.Gray;
                    //USL
                    this.Controls.Find("lblA" + i.ToString() + "USL", true)[0].Text = "-";
                    this.Controls.Find("lblA" + i.ToString() + "USL", true)[0].BackColor = Color.Gray;
                }
            }

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbxComport.Text != "")
                {
                    serialPort1.Close();
                    serialPort1.PortName = cbxComport.Text;
                    serialPort1.Open();
                    if (serialPort1.IsOpen == true)
                    {
                        lblStatus.Text = "Status: connected";
                        string data = serialPort1.ReadExisting();
                        lblTime.Text = lblUpdateTime.Text;
                        TUpdate.Enabled = true;
                        Tsecond.Enabled = true;
                        TEDC.Enabled = true;
                        btnStart.Enabled = false;
                        btnStop.Enabled = true;
                        cbxComport.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("TError: " + ex.ToString(), "error");
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            lblStatus.Text = "Status: disconnected";
            TUpdate.Enabled = false;
            Tsecond.Enabled = false;
            TEDC.Enabled = false;
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            cbxComport.Enabled = true;
        }

        private void Tsecond_Tick(object sender, EventArgs e)
        {
            lblTime.Text = (int.Parse(lblTime.Text) - 1).ToString();
        }

        private void TEDC_Tick(object sender, EventArgs e)
        {
            lblTime.Text = lblUpdateTime.Text;
            //writexml
            if (!Directory.Exists(FSPath + LineID)) 
            { 
                Directory.CreateDirectory(FSPath + LineID);
            }

            XmlTextWriter textWriter = new XmlTextWriter(FSPath + LineID + "\\" + EQID + ".xml", Encoding.UTF8);
            // Opens the document  
            textWriter.WriteStartDocument();
            // Write element  
            textWriter.WriteStartElement("utility");

            textWriter.WriteElementString("datetime", DateTime.Now.ToString("yyyyMMddHHmmss"));
            textWriter.WriteElementString("item_cnt", toRead.Count.ToString());

            for (int i = 0; i < toRead.Count; i++)
            {
                textWriter.WriteStartElement("item");

                textWriter.WriteElementString("name", this.Controls.Find("lblA" + i.ToString() + "ItemName", true)[0].Text);
                textWriter.WriteElementString("type", "X");
                textWriter.WriteElementString("value", this.Controls.Find("lblA" + i.ToString() + "Val", true)[0].Text);

                textWriter.WriteEndElement();
            }

            // Close the document  
            textWriter.WriteEndDocument();  
            // close writer  
            textWriter.Close();
        }

        private void TUpdate_Tick(object sender, EventArgs e)
        {
            string data = serialPort1.ReadExisting();
            string[] data_split = data.Split("\n".ToCharArray());
            string[] Ary_Val;

            if (data_split[data_split.Length - 1].Split(",".ToCharArray()).Length == 6)
            {
                Ary_Val = data_split[data_split.Length - 1].Split(",".ToCharArray());
            }
            else if (data_split[data_split.Length - 2].Split(",".ToCharArray()).Length == 6)
            {
                Ary_Val = data_split[data_split.Length - 2].Split(",".ToCharArray());
            }
            else
            {
                Ary_Val = data_split[data_split.Length - 3].Split(",".ToCharArray());
            }

            for (int i = 0; i < toRead.Count; i++)
            {
                this.Controls.Find("lbl" + toRead[i] + "Val", true)[0].Text = 
                    (float.Parse(Ary_Val[int.Parse(toRead[i].Substring(1,1))]) *
                    a[int.Parse(toRead[i].Substring(1, 1))] +
                    b[int.Parse(toRead[i].Substring(1, 1))]).ToString("#0.0");

                if (this.Controls.Find("lbl" + toRead[i] + "USL", true)[0].Text != "-" || 
                    this.Controls.Find("lbl" + toRead[i] + "LSL", true)[0].Text != "-")
                {
                    this.Controls.Find("lbl" + toRead[i] + "Status", true)[0].BackColor = Color.Green;
                    
                    if (this.Controls.Find("lbl" + toRead[i] + "USL", true)[0].Text != "-") //USL
                    {
                        if (float.Parse(this.Controls.Find("lbl" + toRead[i] + "Val", true)[0].Text) >
                        float.Parse(this.Controls.Find("lbl" + toRead[i] + "USL", true)[0].Text))
                        {
                            this.Controls.Find("lbl" + toRead[i] + "Status", true)[0].BackColor = Color.Red;
                        }
                    }
                    if (this.Controls.Find("lbl" + toRead[i] + "LSL", true)[0].Text != "-") //LSL
                    {
                        if (float.Parse(this.Controls.Find("lbl" + toRead[i] + "Val", true)[0].Text) <
                            float.Parse(this.Controls.Find("lbl" + toRead[i] + "LSL", true)[0].Text))
                        {
                            this.Controls.Find("lbl" + toRead[i] + "Status", true)[0].BackColor = Color.Red;
                        }
                    }
                }
                
                else
                {
                    this.Controls.Find("lbl" + toRead[i] + "Status", true)[0].BackColor = Color.Green;
                }
            }
        }

    }
}
